## cheatsheet

This Class provides a clean, multi-column design intended for Cheat
Sheets. 

It imports the most useful Packages and encloses the document in a
multicol-environment.

See the documentation for a minimal example document.



This class is licensed under the [MIT-License](https://github.com/ACHinrichs/LaTeX-templates/blob/master/LICENSE)